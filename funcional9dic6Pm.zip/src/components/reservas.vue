<template>

  <div class="reservas">
    <div class="container_reservas">
      
      <h2>Reserva</h2>

      <form v-on:submit.prevent="processSignUp">
        <div class="form-group">
        <label>idReserva:</label>
        <input type="text" v-model="user.idReserva" placeholder="Reserva" />
        </div>
        <br /> 
        <div class="form-group">
        <label>nombrecuentaUsuario:</label>
        <input type="text" v-model="user.nombrecuentaUsuario" placeholder="cuenta"/>
        </div>
        <br /> 
        <div class="form-group">
        <label>fechaReserva:</label>
        <input type="text" v-model="user.Nombres" placeholder="Fecha de Reserva" />
        </div>
        <br /> 
        <div class="form-group">
        <label>fechaInicio:</label>
        <input type="text" v-model="user.Apellidos" placeholder="Fecha de Inicio" />
        </div>
    
        <br /> 
        <div class="form-group">
        <label>fechaFin:</label>
         <input type="text" v-model="user.No_documento" placeholder="Fecha de Fin" />
         </div>
        <br /> 
        <div class="form-group">
        <label>personas:</label>
        <input type="text" v-model="user.personas" placeholder="personas" />
        </div>
        <br /> 
        <div class="form-group">
        <label>idHotel:</label>
        <input type="text" v-model="user.idHotel" placeholder="idHotel" />
        </div>
        <br /> 
        <div class="form-group">
        <label>habitacion:</label>
         <input type="text" v-model="user.habitacion" placeholder="Habitacion" />
         </div>
        <br />
        <div class="form-group">
         <label>estado:</label>
        <input type="text" v-model="user.estado" placeholder="Estado" />
        </div>
        <br />
        <div class="form-group">
         <label>medioPago:</label>
        <input type="number" v-model="user.medioPago" placeholder="Medio de Pago" />
        </div>
        <br />
        
        <button type="submit">Reservar</button>
      </form>
    </div>
  </div>
</template>

<script>
import gql from "graphql-tag";
export default {
  name: "reservas",
  data: function () {
    return {
      user: {
        idReserva: "",
        nombrecuentaUsuario: "",
        fechaReserva: "",
        fechaInicio: "",
        fechaFin: "",
        personas: "",
        idHotel: "",
        habitacion: "",
        estado: "",
        medioPago: 0,
      },
    };
  },

};
</script>

<style>

</style>