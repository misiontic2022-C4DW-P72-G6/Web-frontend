<template>
  <div class="information1">
      
    <div class="create-route2">
       
      <h1>Nuestros Hoteles Asociados</h1>
      
    </div>

<div class="cuadro_contenedor">
        <div class="create-route">
          Nombre:<span>{{ catalogoDetailById.Nombre }}</span>
        </div>
        <br />

        <div class="create-route">
          Ubicación:<span>{{ catalogoDetailById.Ubicacion }}</span>
        </div>
        <br />

        <div class="create-route">
          Calificación:<span>{{ catalogoDetailById.Calificacion }}</span>
        </div>
        <br />

        <div class="create-route">
          Descripción:<span>{{ catalogoDetailById.Descripcion }}</span>
        </div>
        <br />

        <div class="create-route">
          Correo: <span>{{ catalogoDetailById.Correo }}</span>
        </div>
        <br />
        <router-link to="/">reserva</router-link>
          
      </div>
        <div class="create-route1">     
       <img src="./imagenes/hot1.jpeg" width="200" height="200" alt="1" >

    </div> 
    <br />

  </div>

  
  

</template>

<script>
import gql from "graphql-tag";

export default {
  name: "catalogo",
  data () {

    return {
     catalogoId:1,
     
      catalogoDetailById: {
        Nombre: "",
        Ubicacion: "",
        Calificacion: "",
        Direccion: "",
        Descripcion: "",
        Correo: "",    


      }

    };
  },


  apollo: {
    catalogoDetailById: {
      query: gql`
        query Query($catalogoId: Int!) {
          catalogoDetailById(catalogoId: $catalogoId) {
            Nombre
            Ubicacion
            Calificacion
            Direccion
            Descripcion
            Correo
          }
        }
      `,
      variables() {
        return {
          catalogoId: this.catalogoId,
        };
      },
    },
  },
};

</script>

<style>
.cuadro_contenedor {
  padding: 10px;
  margin-bottom: 10px;
  background-color: rgb(245, 245, 245);
  border: solid 1px red;
  display: grid;
  grid-template-columns: 33% 33% 33%;
  border-radius: 10px;
  box-shadow: 3px 3px 3px 2px rgba(197, 23, 23, 0.2);
  width: 50%;
  height: auto;
  text-align: right;
 
}
.create-route {
  border-radius: 5px;
  text-align: right;
  margin: 1px;
  padding: 10px;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.information1 {
  margin: 0;
  padding: 0%;
  width: 90%;
  height: 90%;
  display: flex;
  flex-direction: left;
  justify-content: left;
  align-items: center;
}
.information1 h1 {
  font-size: 60px;
  color: #283747;
}
.information1 h2 {
  font-size: 40px;
  color: #283747;
}
.information1 span {
  color: crimson;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.details h3 {
  font-size: 35px;
  color: #283747;
  text-align: center;
}
.details h2 {
  font-size: 35px;
  color: #283747;
}
.details {
  border: 3px solid #283747;
  border-radius: 10px;
  width: 80%;
  height: 80%;
  display: flex;
  flex-direction: column;
  justify-content: right;
  align-items: right;
}
</style>