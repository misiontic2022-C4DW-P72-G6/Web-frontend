<template>
<div class="containerlogin">
 <div class="galeria">
    <input type="radio"  id="_1" checked>
    <input type="radio"  id="_2">
    <input type="radio"  id="_3">
    <input type="radio"  id="_4"> 
                     
                    <img src="./imagenes/hot1.jpeg" width="800" height="300" alt="1" >
                      
                    <img src="./imagenes/hot2.jpeg"  width="800" height="300" alt=" 2">
                     
                    <img src="./imagenes/hot3.jpeg"  width="800" height="300" alt="3">
                      
                    <img src="./imagenes/hot4.jpeg"  width="800" height="300" alt="4">

 </div>

  <div class="logIn_user">
 
   <div class="container_logIn_user">
      <h2>Iniciar sesión</h2>
      <form v-on:submit.prevent="processLogInUser">
        <input type="text" v-model="user.username" placeholder="Usuario" />
        <br />
        <input
          type="password"
          v-model="user.password"
          placeholder="Contraseña"
        />
        <br />
        <button type="submit">Iniciar Sesión</button>
       
 
      </form>
      
    </div>
   </div>    
  </div>

</template>

<script>
import gql from "graphql-tag";
export default {
  name: "LogIn",
  data: function () {
    return {
      user: {
        username: "",
        password: "",
      },
    };
  },
  methods: {
    processLogInUser: async function () {
      await this.$apollo
        .mutate({
          mutation: gql`
            mutation ($credentials: CredentialsInput!) {
              logIn(credentials: $credentials) {
                refresh
                access
              }
            }
          `,
          variables: {
            credentials: this.user,
          },
        })
        .then((result) => {
          let dataLogIn = {
            username: this.user.username,
            token_access: result.data.logIn.access,
            token_refresh: result.data.logIn.refresh,
          };
          this.$emit("completedLogIn", dataLogIn);
        })
        .catch((error) => {
          alert("ERROR 401: Credenciales Incorrectas.");
        });
    },
  },
};
</script>

<style>

.containerlogin {
  margin: 0;
  padding: 0%;
  height: 100%;
  width: 100%;
  display: flex;
  justify-content: right;
  overflow: hidden;

}
.logIn_user {
  margin: 0;
  padding: 0%;
  height: 100%;
  width: 100%;
  display: flex;
  justify-content: right;
  align-items: center;
  float: right;
}


.container_logIn_user {
  border: 3px solid #283747;
  border-radius: 10px;
  width: 25%;
  height: 60%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.logIn_user h2 {
  color: #283747;
}
.logIn_user form {
  width: 70%;
}
.logIn_user input {
  height: 40px;
  width: 100%;
  box-sizing: border-box;
  padding: 10px 20px;
  margin: 5px 0;
  border: 1px solid #283747;
}

.logIn_user button {
  width: 60%;
  height: 40px;
  color: #e5e7e9;
  background: #0e18a3;
  border: 1px solid #e5e7e9;
  border-radius: 50px;
  padding: 10px 25px;
  margin: 5px 0;
  justify-content: left;
  align-items: center;
 
}
.logIn_user button:hover {
  color: #e5e7e9;
  background: rgb(146, 144, 0);
  border: 1px solid #ac0181;
  justify-content: center;
  align-items: center;
  
}



.galeria {
  height: calc( 300px + 3em);
  width: 260px;
  margin:1em auto;
  border: 1px solid rgb(231, 226, 226);
  position: relative;  
  float: right;
}


.galeria img {
  position: absolute;
  top: 0;
  left: 0;
  opacity: 0;
  transition: opacity 3s;
}

.galeria input[type=radio] {
  position: relative;
  bottom: calc(-300px - 1.5em);
  right: .5em;
}

.galeria input[type=radio]:nth-of-type(1):checked ~ img:nth-of-type(1) {
  opacity: 1;
}

.galeria input[type=radio]:nth-of-type(2):checked ~ img:nth-of-type(2) {
  opacity: 1;
}

.galeria input[type=radio]:nth-of-type(3):checked ~ img:nth-of-type(3) {
  opacity: 1;
}

.galeria input[type=radio]:nth-of-type(4):checked ~ img:nth-of-type(4) {
  opacity: 1;
}

 

</style>
