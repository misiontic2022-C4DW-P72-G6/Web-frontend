<template>
    <div class="Bienvenido">
      ¡Bienvenido!
      </div>

         <div class="texto">
          <h2>Hola!  <span>{{userDetailById.Nombres }}</span><br />
            Correo electrónico:  <span>{{userDetailById.Correo }}</span><br />
            Planea con nosotros tus próximas vacaciones...</h2>
            

           <div class="detailsimg">
            <img src="./imagenes/vista.jpeg" width="600" height="400" alt="1" >
          </div>

 

        </div>


    
  
</template>

<script>
import gql from "graphql-tag";
import jwt_decode from "jwt-decode";
export default {
  name: "Home",
  data: function () {
    return {
      userId: jwt_decode(localStorage.getItem("token_refresh")).user_id,
      userDetailById: {
        Nombres: "",
        Correo: "",
        
      },
    };
  },
  apollo: {
    userDetailById: {
      query: gql`
        query ($userId: Int!) {
          userDetailById(userId: $userId) {
            Nombres
            Correo
            
          }
        }
      `,
      variables() {
        return {
          userId: this.userId,
        };
      },
    },
  },
};
</script>

<style>



.texto {
 
  border-radius: 5px;
  text-align: left;
  margin: 1px;
  padding: 0px;
  font-size: 15px;
  font-family:  'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
}
 
  

</style>